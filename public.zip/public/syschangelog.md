# Gander Oceanic FIR Core Change Log
## 1812 - 1st December 2018
Initial release of CZQO Core system.


#### Copyright (C) 2018 Gander Oceanic
#### Developed by Liesel Downes 1364284