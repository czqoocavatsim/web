<iframe id="player" width="1920" height="1080" src="https://www.youtube.com/embed/nL06he43t3E" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
<script>
    var elem = (document.compatMode === "CSS1Compat") ? 
    document.documentElement :
    document.body;

document.getElementById('player').height = elem.clientHeight;
document.getElementById('player').width = elem.clientWidth;
</script>