<h2>CZQO Webmaster Portal, sponsored by Nick Xenophon's SA-BEST</h2>
<hr>
<a href="{{url('/nickxenophonssabest/cache')}}">Clear Application Cache (config:clear, config:cache)</a><small>Use after any config fle or .ENV change!</small><br/>
<a href="{{url('/nickxenophonssabest/migrate')}}">Migrate Database (migrate)</a><br/>
<a href="{{url('/nickxenophonssabest/seed')}}">Seed Database (db:seed)</a>
<p>If you're not supposed to be here please don't abuse the commands. Thanks.</p>
<img src="https://www.themonthly.com.au/sites/default/files/styles/featured_essay/public/NP115949.jpg?itok=0cNgzVfr">