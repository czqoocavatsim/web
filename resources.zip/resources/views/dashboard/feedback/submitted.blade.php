@extends('layouts.master')

@section('navbarprim')

    @parent

@stop

@section('content')
<div class="container" style="margin-top: 30px;">
    <h1>Thank you for submitting your feedback!</h1>
</div>
@stop