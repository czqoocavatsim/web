@extends('layouts.master')

@section('navbarprim')

    @parent

@stop

@section('content')
@stop