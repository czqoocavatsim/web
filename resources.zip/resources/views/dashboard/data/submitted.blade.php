@extends('layouts.master')

@section('navbarprim')

    @parent

@stop

@section('content')
<div class="container" style="margin-top: 30px;">
    <h1>Your request has been emailed.</h1>
</div>
@stop