Extract the CZQXEGGX folder into (YourDocumentsFolder)\EuroScope
Run the setup tool in that folder to edit the profile with your details.
Open CZQXEGGX.prf in EuroScope.